# 컴포넌트 매핑

| 화면 영역 | 권장 컴포넌트 | 데이터 소스 |
|---|---|---|
| 좌측 사이드바 | `SidebarNavigation` | 정적 메뉴 배열 |
| 상단 배지 | `SafetyHeaderBadges` | `dashboard.statusBadges` |
| A 연구 설정 | `ResearchSetupPanel` | `dashboard.setup` |
| B 안전 잠금 | `SafetyLockPanel` | `dashboard.locks` |
| C 워크플로우 | `EvidenceWorkflowGraph` | `dashboard.workflow` |
| KPI | `ResearchKpiStrip` | `dashboard.kpis` |
| 분석 차트 | `AnalyticsChartGrid` | `dashboard.charts` |
| 감사 로그 | `AuditLogTable` | `dashboard.auditLog` |
| 용어 카드 | `GlossaryCards` | `dashboard.glossary` |

## 레이아웃 기준

- 기준 캔버스: `1672 x 941`
- 좌측 사이드바 폭: 약 `194px`
- 메인 시작 X 좌표: 약 `208px`
- 상단 배지 높이: `48px`
- A/B/C 패널 상단: `128px`
- KPI 스트립 상단: `431px`
- 차트 영역 상단: `504px`
- 하단 용어 카드 상단: `814px`

실제 반응형 구현 시에는 이 좌표를 CSS Grid 기준으로 변환하되, 카드 내부 텍스트 줄바꿈이 발생하지 않도록 `min-width`, `overflow`, `text-overflow`, `word-break: keep-all`을 적용한다.
