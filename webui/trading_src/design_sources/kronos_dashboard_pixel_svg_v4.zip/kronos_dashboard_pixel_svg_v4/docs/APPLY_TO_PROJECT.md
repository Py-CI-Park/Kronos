# 프로젝트 적용 지시서

아래 내용을 코딩 에이전트 또는 개발자에게 그대로 전달하면 됩니다.

## 목적

`Kronos 강화학습 연구 커맨드 센터`는 강화학습 매매 실험을 실거래 제품처럼 보이게 만드는 화면이 아니다. 이 화면은 룰 기준선, RL 후보 실험, 비용 가정, 낙폭, 거래 수, 음성/셔플 통제, OOS 분리, 감사 아티팩트의 증거 상태를 검토하는 **로컬 연구 전용 커맨드 센터**이다.

## 적용 우선순위

1. 안전 상태를 최상단에 고정한다.
2. `NO-GO`, `RESEARCH_ONLY`, `23bp`, `ts_imb RULE baseline`을 항상 노출한다.
3. 실거래/브로커/주문/계좌/페이퍼/모델 빌드/수익 준비는 모두 잠금 상태로 표시한다.
4. 연구 설정 → 증거 워크플로우 → KPI → 차트 → 감사 로그 → 용어 카드 순서로 시각 계층을 유지한다.
5. D9 최종 판정은 기본값 `NO-GO`로 둔다.

## 파일 사용법

- `sample.html`: 기준 이미지와 유사한 정적 더미 화면. UI QA 기준으로 사용한다.
- `dummy-data.json`: 컴포넌트 props 또는 API 응답 스키마의 초안으로 사용한다.
- `assets/reference.png`: 원본 기준 이미지. 디자이너/개발자 비교용으로만 사용한다.
- `assets/preview.png`: 현재 SVG 샘플 렌더링 결과.

## Next.js/React 이전 권장 구조

```txt
src/app/research-command-center/page.tsx
src/features/kronos-dashboard/
  components/
    SidebarNavigation.tsx
    SafetyHeaderBadges.tsx
    ResearchSetupPanel.tsx
    EvidenceWorkflowGraph.tsx
    SafetyLockPanel.tsx
    ResearchKpiStrip.tsx
    AnalyticsChartGrid.tsx
    AuditLogTable.tsx
    GlossaryCards.tsx
  data/kronosResearchDashboard.ts
  types.ts
  styles/kronos-dashboard.css
```

## 데이터 계약 초안

```ts
export type GateStatus = 'research_only' | 'stale' | 'missing' | 'malformed' | 'no_go' | 'audited';

export interface SafetyLock {
  name: string;
  status: 'API 미연결(안전 잠금)';
  locked: true;
}

export interface WorkflowNode {
  id: 'D0'|'D1'|'D2'|'D3'|'D4'|'D5'|'D6'|'D7'|'D8'|'D9';
  label: string;
  status: GateStatus;
}

export interface AuditLogRow {
  timeKst: string;
  stage: string;
  result: string;
  actor: string;
}
```

## 구현 시 주의사항

- 이 화면에서는 초록색을 수익/준비/성공 매매 의미로 사용하지 않는다.
- 버튼은 연구 의도 기록용만 활성화한다.
- `실제 학습 실행 잠금` 버튼은 비활성 상태로 둔다.
- 브로커, 주문, 계좌, 페이퍼 트레이딩, 실시간 주문 라우팅 관련 API는 연결하지 않는다.
- 비용 가정은 기본 `23bp`로 표시한다.
- `ts_imb`는 강화학습 모델이 아니라 룰 기준선임을 용어 카드에 반드시 표시한다.
