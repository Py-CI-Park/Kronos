# 안전 가드레일

이 프로젝트의 기본 판정은 `NO-GO`이다. 화면은 연구 증거를 검토하기 위한 것이며, 실거래 또는 수익 준비를 암시하면 안 된다.

## 반드시 유지할 배지

- NO-GO
- RESEARCH_ONLY
- 23bp
- ts_imb RULE baseline
- 실거래 없음
- 브로커 없음
- 주문 없음
- 수익 주장 없음

## 반드시 잠글 항목

- 거래 API
- 주문 라우팅
- 브로커 연결
- 계좌/포지션
- 시장 데이터 실시간 연결
- 알림/텔레그램 주문 연동
- 파일/시스템 쓰기
- 결제/출금

## D9 NO-GO 기본 조건

다음 중 하나라도 해당하면 D9는 NO-GO이다.

- 증거 매니페스트 누락
- OOS 분리 미흡
- 음성/셔플 통제 실패
- 23bp 비용 반영 후 기준선 대비 우위 불명확
- 낙폭 검증 없음
- 거래 수/회전율 검증 없음
- t-통계량 또는 효과 크기 부족
- 감사 로그/아티팩트 불충분

## 금지 문구

- LIVE
- buy / sell
- order now
- broker connected
- account connected
- paper trading ready
- profit ready
- 수익 보장
- 실거래 준비
