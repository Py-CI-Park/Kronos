# Kronos 강화학습 연구 커맨드 센터 — Pixel SVG Static Sample v4

이 패키지는 사용자가 제공한 기준 이미지(`/assets/reference.png`)의 구도에 맞춰 다시 만든 **정적 HTML/SVG 더미 대시보드**입니다. 이전 샘플에서 발생한 렌더링 의존성, 레이아웃 흐트러짐, 글자 줄바꿈/겹침 문제를 줄이기 위해 일반 CSS 그리드가 아니라 **고정 좌표 SVG 캔버스**로 구현했습니다.

## 바로 확인

```bash
open sample.html
```

또는 브라우저에서 `sample.html`을 직접 열면 됩니다. 외부 CDN, React 빌드, Chart 라이브러리, JavaScript 렌더링이 필요 없습니다.

## 포함 파일

```txt
kronos_dashboard_pixel_svg_v4/
├─ sample.html                  # 실제 구현 샘플: 고정 좌표 SVG + 더미 데이터 포함
├─ sample_reference_exact.html  # 기준 이미지를 1:1로 확인하는 비교용 HTML
├─ dummy-data.json              # 화면에 사용한 더미 데이터 계약 예시
├─ README.md
├─ build_svg.py                 # sample.html 생성 스크립트
├─ assets/
│  ├─ reference.png             # 사용자가 제공한 기준 이미지
│  ├─ sample.svg                # sample.html 내부 SVG 추출본
│  └─ preview.png               # SVG 렌더링 미리보기
└─ docs/
   ├─ APPLY_TO_PROJECT.md
   ├─ COMPONENT_MAP.md
   └─ SAFETY_GUARDRAILS.md
```

## 이번 수정의 핵심

- 기준 이미지 크기와 동일한 `1672 x 941` 고정 캔버스 사용
- 좌측 사이드바, 상단 안전 배지, A/B/C 패널, KPI 카드, 차트 6종, 감사 로그, 하단 용어 카드 배치 재정렬
- 모든 텍스트를 SVG `<text>` 좌표로 배치하여 브라우저 레이아웃 줄바꿈으로 인한 글자 겹침 최소화
- 더미 데이터는 `dummy-data.json`과 `sample.html` 내부 `script[type="application/json"]#kronos-dummy-data`에 모두 포함
- `NO-GO`, `RESEARCH_ONLY`, `23bp`, `ts_imb RULE baseline`, `실거래 없음`, `브로커 없음`, `주문 없음`, `수익 주장 없음`을 상단에 명확히 표시
- 실거래, 브로커, 주문, 계좌, 수익 주장, 모델 배포 준비를 암시하는 UI는 만들지 않음

## 권장 적용 방식

`sample.html`은 화면을 최대한 이미지와 맞추기 위한 정적 기준 샘플입니다. 실제 Next.js/React 프로젝트에서는 `docs/COMPONENT_MAP.md` 기준으로 다음 컴포넌트로 분리하는 방식을 권장합니다.

```txt
KronosResearchDashboard
├─ SidebarNavigation
├─ SafetyHeaderBadges
├─ ResearchSetupPanel
├─ EvidenceWorkflowGraph
├─ SafetyLockPanel
├─ ResearchKpiStrip
├─ AnalyticsChartGrid
├─ AuditLogTable
└─ GlossaryCards
```

차트 라이브러리를 붙일 경우 ECharts 또는 Recharts를 사용할 수 있지만, 이 화면은 연구 증거 검토용이므로 색상 의미를 반드시 유지해야 합니다.

| 색상 | 의미 |
|---|---|
| Cyan / Blue | 연구 전용, 데이터/증거 존재, 기준선 정보 |
| Amber | stale, 점검 필요, 비용 가정 |
| Red | NO-GO, missing, 실패, 안전 잠금 |
| Purple | malformed, 반증/민감도, 형식 오류 |
| Green | 데이터 로드 또는 감사 성공에만 제한적으로 사용. 수익 준비 의미 금지 |

## 금지 사항

이 대시보드는 연구 전용입니다. 다음 기능 또는 문구를 추가하지 마십시오.

- 실거래 실행
- 브로커 연결
- 주문 전송
- 계좌 접근
- 페이퍼 트레이딩
- 자동 배포
- 수익 준비/수익 보장/실거래 준비
- LIVE, buy, sell, order now, broker connected, account connected, profit ready

## 더미 데이터 교체 위치

1. `dummy-data.json`을 실제 연구 API 응답 스키마로 교체합니다.
2. React/Next.js로 이전할 때 `sample.html` 내부의 JSON 구조를 `src/data/kronosResearchDashboard.ts`로 옮깁니다.
3. 차트는 더미 SVG를 실제 ECharts 옵션으로 교체합니다.
4. D9가 `NO-GO`가 아닌 상태를 표시하려면 먼저 `docs/SAFETY_GUARDRAILS.md`의 조건을 통과해야 합니다. 기본값은 항상 `NO-GO`입니다.

## 참고

`sample_reference_exact.html`은 기준 이미지를 그대로 보여주는 비교용입니다. 실제 프론트엔드 구현 기준은 `sample.html`입니다.
