from html import escape
from pathlib import Path
import json
W,H=1672,941
colors={
    'bg0':'#020914','bg1':'#061422','panel':'#0a1a2b','panel2':'#081522','line':'#2a4055','line2':'#31516c','text':'#eaf4ff','muted':'#a8b7c8','dim':'#7d8ea3','cyan':'#19d9f0','blue':'#2d85ff','purple':'#a15cff','amber':'#ffbd32','red':'#ff4c4c','green':'#2bf085'
}
svg=[]

def add(s): svg.append(s)

def t(x,y,txt,size=12,fill=None,weight=400,anchor='start',opacity=1,cls=''):
    fill=fill or colors['text']
    add(f'<text x="{x}" y="{y}" fill="{fill}" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}" opacity="{opacity}" class="{cls}">{escape(str(txt))}</text>')

def mt(x,y,lines,size=12,fill=None,weight=400,line=18,anchor='start'):
    fill=fill or colors['text']
    add(f'<text x="{x}" y="{y}" fill="{fill}" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}">')
    for i,ln in enumerate(lines):
        dy=0 if i==0 else line
        add(f'<tspan x="{x}" dy="{dy}">{escape(str(ln))}</tspan>')
    add('</text>')

def rect(x,y,w,h,r=6,fill=None,stroke=None,sw=1,op=1,extra=''):
    fill=fill or colors['panel']
    stroke=stroke or colors['line']
    add(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" opacity="{op}" {extra}/>')

def line(x1,y1,x2,y2,stroke=None,sw=1,op=1,dash=''):
    stroke=stroke or '#8ea4b7'
    d=f' stroke-dasharray="{dash}"' if dash else ''
    add(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}" opacity="{op}"{d}/>' )

def poly(points,stroke,sw=2,fill='none',dash=''):
    pts=' '.join(f'{x},{y}' for x,y in points)
    d=f' stroke-dasharray="{dash}"' if dash else ''
    add(f'<polyline points="{pts}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"{d}/>' )

def path(d,stroke,sw=2,fill='none',dash=''):
    dd=f' stroke-dasharray="{dash}"' if dash else ''
    add(f'<path d="{d}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"{dd}/>' )

def badge(x,y,w,h,label,kind='dim',icon='●',sub=None):
    stroke={'red':colors['red'],'cyan':colors['cyan'],'blue':'#3c70c0','dim':'#3e566b'}.get(kind,'#3e566b')
    fill={'red':'url(#badgeRed)','cyan':'url(#badgeCyan)','blue':'url(#badgeBlue)','dim':'url(#badgeDim)'}.get(kind,'url(#badgeDim)')
    rect(x,y,w,h,8,fill,stroke,1.2)
    circ_fill={'red':'#442025','cyan':colors['cyan'],'blue':'#08243c','dim':'#102337'}.get(kind,'#102337')
    add(f'<circle cx="{x+32}" cy="{y+h/2}" r="14" fill="{circ_fill}" stroke="{stroke}" stroke-width="1.5"/>')
    t(x+32,y+h/2+5,icon,14, '#08131e' if kind=='cyan' else colors['text'],900,'middle')
    if sub:
        t(x+55,y+19,label,12,colors['text'] if kind!='cyan' else colors['cyan'],900)
        t(x+55,y+34,sub,10,colors['muted'],700)
    else:
        t(x+55,y+30,label,15, colors['cyan'] if kind=='cyan' else colors['text'],900)

def panel(x,y,w,h,tag,title,small=None):
    rect(x,y,w,h,9,'url(#panelGrad)',colors['line'],1.1)
    rect(x+1,y+1,w-2,1,0,'url(#panelTop)', 'none',0)
    rect(x+12,y+13,26,26,5,'url(#tagGrad)','#54a9ff',1)
    t(x+25,y+33,tag,18,'#f4fbff',950,'middle')
    t(x+48,y+32,title,16,'#f5fbff',950)
    if small:
        t(x+48+len(title)*8.7,y+32,small,11,colors['dim'],700)

def input_box(x,y,w,h,text,arrow=False):
    rect(x,y,w,h,5,'#0a1826','#263d53',1)
    t(x+10,y+h/2+4,text,11,'#dce8f2',500)
    if arrow: t(x+w-13,y+h/2+5,'⌄',14,'#bbd1e4',800,'middle')

def button(x,y,w,h,text,disabled=False):
    if disabled:
        rect(x,y,w,h,6,'url(#btnOff)','#415060',1)
        t(x+w/2,y+h/2+5,text,11,'#8292a0',900,'middle')
    else:
        rect(x,y,w,h,6,'url(#btnOn)','#268ee9',1)
        t(x+w/2,y+h/2+5,text,12,'#ffffff',950,'middle')

def node(x,y,code,label,sub='',kind='cyan'):
    stroke={'cyan':colors['cyan'],'red':colors['red'],'purple':colors['purple'],'amber':colors['amber']}.get(kind,colors['cyan'])
    fill={'cyan':'#082d40','red':'#331319','purple':'#28153e','amber':'#30250e'}.get(kind,'#082d40')
    rect(x,y,92,60,8,fill,stroke,2)
    add(f'<circle cx="{x+46}" cy="{y-1}" r="16" fill="{fill}" stroke="{stroke}" stroke-width="2"/>')
    t(x+46,y+4,code,13,stroke,950,'middle')
    if isinstance(label,list): mt(x+46,y+29,label,12,'#f4fbff' if kind!='red' else colors['red'],900,16,'middle')
    else: t(x+46,y+33,label,14,'#f4fbff' if kind!='red' else colors['red'],950,'middle')
    if sub:
        if isinstance(sub, str) and '\n' in sub:
            mt(x+46,y+78,sub.split('\n'),10,colors['muted'] if kind!='red' else colors['red'],700,12,'middle')
        else:
            t(x+46,y+82,sub,10,colors['muted'] if kind!='red' else colors['red'],700,'middle')

def chart_frame(x,y,w,h,num,title):
    rect(x,y,w,h,8,'url(#chartGrad)',colors['line'],1)
    t(x+15,y+22,f'{num}) {title}',13,'#f5fbff',950)

def axes(x,y,w,h):
    line(x+34,y+h-28,x+w-14,y+h-28,'#607487',1,.9)
    line(x+34,y+34,x+34,y+h-28,'#607487',1,.9)
    for yy in [y+49,y+71,y+93]: line(x+34,yy,x+w-14,yy,'#263b4f',1,.55,'3 4')

# document
add(f'''<!doctype html><html lang="ko"><head><meta charset="utf-8"/><meta name="viewport" content="width={W}, initial-scale=1"/><title>Kronos 강화학습 연구 커맨드 센터 - Pixel SVG Sample</title><style>
html,body{{margin:0;background:#000;color:#eaf4ff;font-family:"Noto Sans CJK KR","Noto Sans KR","Malgun Gothic","Apple SD Gothic Neo",Arial,sans-serif;}}
body{{min-height:100vh;display:flex;align-items:flex-start;justify-content:center;overflow:auto;}}
.dashboard{{width:{W}px;height:{H}px;display:block;background:#020914;}}
text{{font-family:"Noto Sans CJK KR","Noto Sans KR","Malgun Gothic","Apple SD Gothic Neo",Arial,sans-serif;dominant-baseline:auto;}}
.no-select{{user-select:none;}}
</style></head><body>''')
add(f'<svg class="dashboard no-select" xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-label="강화학습 연구 커맨드 센터 정적 더미 HTML 샘플">')
add('''<defs>
<linearGradient id="bgGrad" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#020914"/><stop offset="0.48" stop-color="#071422"/><stop offset="1" stop-color="#06111d"/></linearGradient>
<radialGradient id="glow1" cx="0.62" cy="0.05" r="0.8"><stop stop-color="#123458" stop-opacity="0.55"/><stop offset="0.55" stop-color="#123458" stop-opacity="0"/></radialGradient>
<linearGradient id="sideGrad" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#06111e"/><stop offset="0.5" stop-color="#071827"/><stop offset="1" stop-color="#04101c"/></linearGradient>
<linearGradient id="panelGrad" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#0d1c2c" stop-opacity="0.98"/><stop offset="1" stop-color="#07131f" stop-opacity="0.98"/></linearGradient>
<linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#0a1b2b" stop-opacity="0.96"/><stop offset="1" stop-color="#06121d" stop-opacity="0.96"/></linearGradient>
<linearGradient id="badgeRed" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#20141c"/><stop offset="1" stop-color="#0d1520"/></linearGradient>
<linearGradient id="badgeCyan" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#0a2d42"/><stop offset="1" stop-color="#081826"/></linearGradient>
<linearGradient id="badgeBlue" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#12233a"/><stop offset="1" stop-color="#091725"/></linearGradient>
<linearGradient id="badgeDim" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#152635"/><stop offset="1" stop-color="#0b1a28"/></linearGradient>
<linearGradient id="tagGrad" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#2d7cde"/><stop offset="1" stop-color="#144b88"/></linearGradient>
<linearGradient id="btnOn" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#1a9cff"/><stop offset="1" stop-color="#0b65ba"/></linearGradient>
<linearGradient id="btnOff" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#233340"/><stop offset="1" stop-color="#182531"/></linearGradient>
<linearGradient id="panelTop" x1="0" y1="0" x2="1" y2="0"><stop stop-color="#74beff" stop-opacity="0"/><stop offset="0.5" stop-color="#74beff" stop-opacity="0.45"/><stop offset="1" stop-color="#74beff" stop-opacity="0"/></linearGradient>
<marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#91a8ba"/></marker>
<filter id="glow"><feGaussianBlur stdDeviation="2.2" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
</defs>''')
# background
rect(0,0,W,H,0,'url(#bgGrad)','none',0)
rect(0,0,W,H,0,'url(#glow1)','none',0)
# grid
for x in range(0,W,24): line(x,0,x,H,'#ffffff',0.4,.018)
for y in range(0,H,24): line(0,y,W,y,'#ffffff',0.4,.018)
# sidebar
rect(0,0,194,H,0,'url(#sideGrad)','#254156',1)
line(194,0,194,H,'#254156',1)
# logo
t(68,43,'RL',18,'#fff',950); t(68,62,'RESEARCH',18,'#fff',950); t(68,79,'COMMAND',12,'#b9c9dc',800); t(68,94,'CENTER',12,'#b9c9dc',800)
add('<circle cx="39" cy="58" r="21" fill="#081b2d" stroke="#19d9f0" stroke-width="2" filter="url(#glow)"/>')
add('<path d="M35 41 C22 52,24 70,37 78 M43 41 C56 52,54 70,41 78 M39 41 L39 77" stroke="#19d9f0" stroke-width="2" fill="none"/>')
add('<path d="M30 48 C36 43,43 43,49 48 M28 59 C35 55,43 55,50 59 M29 69 C36 65,43 65,49 69" stroke="#8e5cff" stroke-width="1.5" fill="none"/>')
# sidebar nav
x=10;y=88
rect(x,y,174,37,7,'#153e74','#2979e6',1)
t(x+30,y+24,'⌘',15,'#d9eaff',900,'middle'); t(x+50,y+24,'대시보드',14,'#fff',900)
nav_y=145
for heading,items in [('연구 설계',[('A','연구 설정'),('B','안전 잠금'),('C','D0-D9 워크플로우')]),('실험 & 분석',[('▦','데이터 검증'),('⌁','특징 공학'),('⚙','모델 실험'),('▥','백테스트'),('▥','결과 분석')]),('거버넌스',[('◴','감사 로그'),('◎','가드레일'),('▥','용어 사전'),('▱','연구 기록')])]:
    t(22,nav_y,heading,14,'#eef6ff',800); nav_y+=28
    for ico,lab in items:
        t(30,nav_y,ico,14,'#d5e5f6',800,'middle'); t(52,nav_y,lab,14,'#d5e5f6',500); nav_y+=40 if lab=='D0-D9 워크플로우' else 38
    line(18,nav_y-15,174,nav_y-15,'#263b4e',1)
# sidebar mode
rect(10,668,174,154,9,'#0b2034','#244055',1)
t(97,698,'⚗ 연구 모드',15,'#e7f7ff',800,'middle')
rect(31,715,132,34,17,'#0c4057','none',0); t(97,738,'RESEARCH ONLY',16,colors['cyan'],950,'middle')
mt(97,779,['실거래 · 브로커 · 주문 · 수익','모두 비활성'],13,'#cdd9e8',500,23,'middle')
t(32,898,'v1.0.0-research',12,'#4d99e8',700)
# top title
t(223,41,'강화학습 연구 커맨드 센터',32,'#f7fbff',950)
t(225,69,'연구 전용 증거 검토 환경 · 실거래·브로커·주문·수익 경로는 모두 비활성화되어 있습니다.',15,'#d1dae5',500)
# badges
bx=217; by=77; gap=12
widths=[142,204,158,196,165,165,165,166]
labels=[('NO-GO','red','⊖',None),('RESEARCH_ONLY','cyan','♣',None),('23bp','blue','⏱','비용 가정'),('ts_imb RULE baseline','blue','⌬','비교 기준'),('실거래 없음','dim','⊘',None),('브로커 없음','dim','♜',None),('주문 없음','dim','▥',None),('수익 주장 없음','dim','⌁',None)]
for w,(lab,kind,ico,sub) in zip(widths,labels):
    badge(bx,by,w,48,lab,kind,ico,sub); bx+=w+gap
# panels
panel(208,128,356,294,'A','Research Setup Panel')
panel(573,128,661,294,'C','D0-D9 Evidence Workflow Graph')
panel(1243,128,414,294,'B','Safety Lock Panel')
# setup fields
fx=222; fy=181; label_x=222; input_x=330
fields=[('연구 의도(선택)','호가창 RL 반증 실험 · Orderbook falsification'),('알고리즘(선택)','DQN/PPO 연구 비교 · RL experiment'),('비교 기준(베이스라인)','ts_imb 룰 기준선 · RULE baseline'),('종목 코드(콤마 구분)','000250, 005930, 035420'),('비용 가정(단축)','23bp'),('기간(예시)','2022-01-01 ~ 2024-12-31')]
for i,(lab,val) in enumerate(fields):
    yy=fy+i*28
    t(label_x,yy+17,lab,12,'#c1ccdc',800)
    input_box(input_x,yy,220,25,val,arrow=i<3)
button(222,348,156,33,'선택한 연구 의도 기록')
button(388,348,162,33,'🔒 실제 학습 실행 잠금',True)
mt(222,397,['위 버튼은 연구 의도 기록용입니다.','주문·브로커·수익 경로를 열지 않습니다.'],10,'#a8b8c7',500,14)
# locks
sx=1257; sy=177; rowh=28
locks=['거래 API','주문 라우팅','브로커 연결','계좌/포지션','시장 데이터(실시간)','알림/텔레그램','파일/시스템 쓰기','결제/출금']
rect(sx,sy,386,rowh*8,4,'#07121e','#23394d',1)
for i,name in enumerate(locks):
    yy=sy+i*rowh
    if i>0: line(sx,yy,sx+386,yy,'#22384c',1)
    t(sx+12,yy+18,name,13,'#d6e3f1',500)
    rect(sx+132,yy+4,202,20,5,'#37171d','#9d2931',1)
    t(sx+233,yy+18,'API 미연결(안전 잠금)',11,'#ff6661',900,'middle')
    t(sx+362,yy+19,'▣',14,'#e9eef8',900,'middle')
# workflow connectors
# draw connecting lines
for x1,x2,y in [(675,697,209),(790,813,209),(905,928,209),(1020,1043,209)]: add(f'<line x1="{x1}" y1="{y}" x2="{x2}" y2="{y}" stroke="#91a8ba" stroke-width="2" marker-end="url(#arrow)"/>')
path('M1135 209 H1194 V270 H1135', '#91a8ba',2,'none')
for x1,x2,y in [(675,697,294),(790,813,294),(905,928,294),(1020,1043,294)]: add(f'<line x1="{x1}" y1="{y}" x2="{x2}" y2="{y}" stroke="#91a8ba" stroke-width="2" marker-end="url(#arrow)"/>')
node(582,179,'D0',['연구 의도','정의'],'의도 기록')
node(697,179,'D1',['데이터 수집','& 카탈로그'],'원천/범위')
node(813,179,'D2',['데이터 검증','(품질)'],'완전성/정합성')
node(929,179,'D3',['특징 공학','& 검증'],'누수/분포')
node(1044,179,'D4',['실험 설계','(가드레일)'],'룰/비용/률')
node(582,264,'D5',['모델 학습','(연구 전용)'],'비학습 경로')
node(697,264,'D6',['백테스트','(비용 반영)'],'23bp 포함')
node(813,264,'D7',['통계 검정','(유의성)'],'p-value/효과크기')
node(929,264,'D8',['반증 시도','& 민감도'],'강건성 검증','purple')
node(1044,264,'D9','NO-GO','배포 · 실거래\n절대 금지','red')
# red sub text clean overlay
# legend
rect(588,382,631,28,7,'#07121e','#294257',1)
leg=[(620,'연구 전용(통과)',colors['cyan']),(744,'스테일(점검 필요)',colors['amber']),(888,'누락(실패)',colors['red']),(985,'형식 오류',colors['purple']),(1076,'NO-GO(배포 금지)',colors['red'])]
for x,lab,c in leg:
    if 'NO-GO' in lab: rect(x,391,11,11,3,'none',c,1)
    else: add(f'<circle cx="{x+5}" cy="396" r="6" fill="{c}"/>')
    t(x+18,400,lab,12,'#c1d1e1',500)
# metrics
mx=208; my=431; widths=[226,257,225,222,225,279]
metrics=[('▰','데이터 커버리지 (일)','744 / 744','100.0%',colors['cyan'],colors['green']),('⌁','D2 품질 점수(평균)','98.6 / 100','우수',colors['cyan'],colors['green']),('⬡','백테스트 샤프(평균)','-0.12','No Edge',colors['red'],colors['red']),('▥','승률(평균)','47.3%','Below 50%',colors['text'],colors['red']),('⚖','t-통계량 (평균)','-0.64','|t|<1.96',colors['red'],colors['red']),('⬟','D9 최종 상태','NO-GO','배포 · 실거래 금지',colors['red'],colors['red'])]
for w,(ico,lab,val,sub,vc,sc) in zip(widths,metrics):
    rect(mx,my,w,65,9,'url(#panelGrad)',colors['line'],1)
    t(mx+29,my+42,ico,28,'#89a7c2',800,'middle')
    t(mx+62,my+20,lab,12,'#b6c4d4',800)
    t(mx+62,my+49,val,25,vc,950)
    t(mx+72+(len(val)*13),my+49,sub,11,sc,900)
    mx+=w+9
# charts
chart_frame(208,504,363,145,'1','누적 수익 곡선(비용 반영)'); axes(208,504,363,145)
# chart 1
poly([(250,574),(270,577),(292,581),(315,590),(338,603),(360,597),(382,614),(405,608),(427,618),(450,626),(472,632),(495,625),(528,608),(550,594)],colors['purple'],2)
poly([(250,571),(270,573),(292,575),(315,579),(338,583),(360,586),(382,590),(405,596),(427,603),(450,610),(472,618),(495,615),(528,603),(550,588)],colors['cyan'],2)
poly([(250,570),(310,580),(370,590),(430,603),(490,611),(550,600)],colors['amber'],2,dash='6 4')
for xx,lab in [(250,'2022-01'),(340,'2022-07'),(430,'2023-01'),(520,'2024-07')]: t(xx,636,lab,10,colors['muted'],500)
for yy,lab in [(547,'200'),(590,'-200'),(615,'-600')]: t(219,yy,lab,10,colors['muted'],500)
t(535,575,'-88',16,colors['amber'],900); t(535,593,'-154',16,colors['cyan'],900); t(535,611,'-231',16,colors['purple'],900)
t(414,534,'RL(DQN)  ─  RL(PPO)  ·· ts_imb RULE',10,colors['muted'],500)
chart_frame(578,504,363,145,'2','월별 수익 분포(비용 반영, bp)'); axes(578,504,363,145)
# bar chart
base_y=615
xs=[625,695,765,835,905]
vals=[(6,5,4),(8,10,7),(10,11,9),(8,7,9),(3,2,3)]
for x,v in zip(xs,vals):
    for j,(vv,c) in enumerate(zip(v,[colors['cyan'],colors['purple'],colors['amber']])):
        h=vv*5
        rect(x+j*15,base_y-h,11,h,0,c,'none',0); t(x+j*15+5,base_y-h-4,str(vv),10,'#dce8f2',700,'middle')
for x,lab in zip(xs,['<-200','-200~-100','-100~0','0~100','>200']): t(x,637,lab,10,colors['muted'],500)
chart_frame(948,504,376,145,'3','롤링 샤프(60일)'); axes(948,504,376,145)
poly([(986,575),(1010,571),(1034,578),(1060,572),(1085,582),(1110,579),(1138,586),(1168,583),(1194,590),(1220,594),(1250,591),(1295,586)],colors['cyan'],2)
poly([(986,578),(1010,579),(1034,584),(1060,586),(1085,591),(1110,595),(1138,599),(1168,604),(1194,608),(1220,612),(1250,609),(1295,604)],colors['purple'],2)
poly([(986,577),(1030,580),(1080,585),(1130,590),(1180,596),(1295,598)],colors['amber'],2,dash='6 4')
for x,lab in [(986,'2022-01'),(1072,'2022-07'),(1162,'2023-07'),(1250,'2024-07')]: t(x,637,lab,10,colors['muted'],500)
t(1284,572,'-0.08',16,colors['amber'],900); t(1284,590,'-0.14',16,colors['cyan'],900); t(1284,608,'-0.21',16,colors['purple'],900)
t(1190,534,'─ RL(DQN)   ─ RL(PPO)',10,colors['muted'],500)
chart_frame(208,657,363,145,'4','최대 낙폭(%)'); axes(208,657,363,145)
poly([(250,704),(280,710),(310,722),(340,742),(370,736),(400,746),(430,760),(460,768),(490,758),(520,742),(550,734)],colors['purple'],2)
poly([(250,701),(280,706),(310,718),(340,728),(370,735),(400,741),(430,746),(460,750),(490,746),(520,740),(550,738)],colors['cyan'],2)
poly([(250,698),(310,710),(370,724),(430,734),(490,738),(550,725)],colors['amber'],2,dash='6 4')
for yy,lab in [(690,'0%'),(713,'-10%'),(737,'-20%'),(760,'-30%'),(783,'-40%')]: t(219,yy,lab,10,colors['muted'],500)
t(528,721,'-12.1',16,colors['amber'],900); t(528,740,'-17.3',16,colors['cyan'],900); t(528,758,'-22.6',16,colors['purple'],900)
chart_frame(578,657,363,145,'5','거래 비용 기여(bp)'); axes(578,657,363,145)
for i,(x,total) in enumerate(zip([640,700,760,820,880],[21,22,23,24,22])):
    rect(x,743,35,20,0,colors['amber'],'none',0); rect(x,726,35,17,0,colors['cyan'],'none',0); rect(x,709,35,17,0,colors['purple'],'none',0)
    t(x+17,703,f'{total}bp',12,'#dce8f2',700,'middle'); t(x+17,756,'7',10,'#fff',700,'middle'); t(x+17,738,'7',10,'#fff',700,'middle'); t(x+17,721,'8',10,'#fff',700,'middle')
for x,lab in zip([640,700,760,820,880],['2022H1','2022H2','2023H1','2023H2','2024H1']): t(x,788,lab,10,colors['muted'],500)
chart_frame(948,657,376,145,'6','표본 외 성과(최근 6개월, bp)'); axes(948,657,376,145)
for x,vals in zip([1008,1070,1138,1206,1274],[(-35,-42,0),(28,19,8),(-21,-33,-7),(12,5,-9),(-19,-11,-102)]):
    for j,(v,c) in enumerate(zip(vals,[colors['blue'],colors['cyan'],colors['purple']])):
        y=728-v*0.45 if v>0 else 728
        h=abs(v)*0.45
        if v>=0: rect(x+j*15,y,12,h,0,c,'none',0)
        else: rect(x+j*15,728,12,h,0,c,'none',0)
        t(x+j*15+6,(y-4 if v>=0 else 728+h+10),str(v),9,'#dce8f2',700,'middle')
for x,lab in zip([1008,1070,1138,1206,1274],['2024-07','2024-08','2024-09','2024-10','합계']): t(x,789,lab,10,colors['muted'],500)
# audit panel
panel(1331,504,326,298,'F','Audit Log', '(최근 12건)')
t(1615,526,'전체 보기 →',12,colors['cyan'],900,'end')
ax=1344; ay=548
headers=['시간(KST)','단계','결과','사용자/시스템']; col=[0,100,134,210]
for c,h in zip(col,headers): t(ax+c,ay,h,10,'#94a8ba',900)
line(ax,ay+10,1632,ay+10,'#2c455b',1)
rows=[('2024-12-15 09:41','D0','기록','researcher_01'),('2024-12-15 09:42','D1','통과','system'),('2024-12-15 09:45','D2','통과','system'),('2024-12-15 09:48','D3','통과','researcher_01'),('2024-12-15 09:51','D4','통과','system'),('2024-12-15 10:02','D5','완료','system'),('2024-12-15 10:28','D6','완료','system'),('2024-12-15 10:41','D7','실패','researcher_01'),('2024-12-15 10:55','D8','실패','system'),('2024-12-15 11:03','D9','NO-GO','system'),('2024-12-15 11:04','요약','생성','system'),('2024-12-15 11:05','리포트','저장','researcher_01')]
for i,row in enumerate(rows):
    yy=ay+27+i*18
    line(ax,yy+5,1632,yy+5,'#5f7a94',0.8,.22)
    c=''
    for j,val in enumerate(row):
        fill=colors['text']
        if j==2 and val in ['통과','완료']: fill=colors['green']
        if j==2 and val in ['실패','NO-GO']: fill=colors['red']
        if j==2 and val in ['기록','생성','저장']: fill=colors['cyan']
        t(ax+col[j],yy,val,9.5,fill,900 if j==2 else 500)
# glossary
# Cards
for x,w,kind in [(208,342,'cyan'),(560,324,'purple'),(896,333,'cyan'),(1242,415,'amber')]:
    stroke={'cyan':colors['line'],'purple':colors['purple'],'amber':'#725e2b'}[kind]
    fill='#0b1f2e' if kind!='amber' else '#201e16'
    rect(x,814,w,114,9,fill,stroke,1)
# contents
t(246,872,'▰',38,colors['cyan'],900,'middle')
t(286,844,'ts_imb',18,colors['cyan'],950); t(348,844,'(time-scaled imbalance)',12,'#dce8f2',800)
mt(286,866,['최근 봇 간 매수·매도 잔량 불균형을 시간 가중으로','스케일링한 지표.','기준선 룰: ts_imb > 0 → 매수, ts_imb < 0 → 매도.'],11,'#d2dce7',500,17)
t(598,872,'⚗',38,colors['purple'],900,'middle')
t(638,844,'RL 단어',18,colors['purple'],950)
mt(638,866,['DQN: 가치 기반 강화학습(이산 행동).','PPO: 정책 기반 강화학습(클리핑 기반).','보상: 비용(23bp) 반영 후 수익(bp) 기준.'],11,'#d2dce7',500,18)
t(934,872,'⬟',38,colors['cyan'],900,'middle')
t(974,844,'가드레일(핵심)',18,colors['cyan'],950)
mt(974,866,['비용 23bp, 롤북 윈도우 고정, 미래 정보 사용','금지, 데이터 누수 방지, 표본 외 검증 필수.','D9=NO-GO 이면 배포·실거래 절대 금지.'],11,'#d2dce7',500,18)
t(1284,872,'⚖',38,colors['amber'],900,'middle')
t(1324,844,'NO-GO 정의',18,colors['amber'],950)
mt(1324,866,['샤프 ≤ 0, 승률 ≤ 50%, |t-통계량| < 1.96 또는','반증/민감도에서 취약 시 D9 = NO-GO.','모든 실험은 연구 전용이며 실거래로 이어지지 않습니다.'],11,'#d2dce7',500,18)
# close svg + embedded data
add('</svg>')
dummy={
  'title':'강화학습 연구 커맨드 센터','mode':'RESEARCH_ONLY','status':'NO-GO','costAssumption':'23bp','baseline':'ts_imb RULE baseline','locks':[{'name':x,'status':'API 미연결(안전 잠금)'} for x in locks],
  'universe':['000250','005930','035420'],'period':'2022-01-01 ~ 2024-12-31','workflow':['D0','D1','D2','D3','D4','D5','D6','D7','D8','D9'],
  'kpis':metrics,'auditLog':rows
}
add('<script type="application/json" id="kronos-dummy-data">')
add(escape(json.dumps(dummy,ensure_ascii=False,indent=2)))
add('</script>')
add('</body></html>')
Path('/mnt/data/kronos_dashboard_pixel_svg_v4/sample.html').write_text('\n'.join(svg), encoding='utf-8')
Path('/mnt/data/kronos_dashboard_pixel_svg_v4/dummy-data.json').write_text(json.dumps(dummy,ensure_ascii=False,indent=2), encoding='utf-8')
